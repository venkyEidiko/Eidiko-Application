package com.eidiko.service;

import java.util.List;


import com.eidiko.entity.Roles_Table;

public interface RoleInterface {

	public  List<Roles_Table> getAllRoles();
}
