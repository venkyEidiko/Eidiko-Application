package com.eidiko.mapping;

public class EmployeeMapping {

}
