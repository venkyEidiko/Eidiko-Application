package com.eidiko.exception_handler;

public class FormatMismatchException  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FormatMismatchException(String message) {
        super(message);
    }
}
