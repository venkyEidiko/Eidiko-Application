package com.eidiko.exception_handler;

public class FileUploadException extends Exception{
    public FileUploadException(String message) {
        super(message);
    }
}