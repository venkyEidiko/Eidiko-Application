package com.eidiko.serviceimplementation;

import java.io.IOException;
import java.text.ParseException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.eidiko.dto.AvgHoursAndOnTimeArrivalDto;
import com.eidiko.dto.EmployeeAttendanceDTO;
import com.eidiko.entity.EmployeeAttendance;
import com.eidiko.excelreader.ExcelReader;
import com.eidiko.exception_handler.FileExtensionNotFound;
import com.eidiko.exception_handler.FormatMismatchException;
import com.eidiko.exception_handler.UserNotFoundException;
import com.eidiko.repository.EmpAttendanceRepository;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmpAttendanceService {

	@Autowired
	private EmpAttendanceRepository attendanceRepository;

	@Autowired
	private ExcelReader excelReader;

	public String save(MultipartFile file)
			throws IOException, FileExtensionNotFound, ParseException, FormatMismatchException {
		if (!ExcelReader.checkExcelFormat(file)) {
			throw new FileExtensionNotFound("File extension not found. Please use .XLSX");
		}

		List<EmployeeAttendance> saveAttendanceData = excelReader.saveAttendanceData(file);

		log.info("Save data: {}", saveAttendanceData);

		Iterable<EmployeeAttendance> saveAll = attendanceRepository.saveAll(saveAttendanceData);

		if (saveAll != null) {
			return "Attendance record has been created...!";
		} else {
			return "Attendance record has not been created...X";
		}
	}

	public List<EmployeeAttendanceDTO> getByEmployeeId(Long empid) throws UserNotFoundException {

		List<EmployeeAttendanceDTO> dtoList = new ArrayList<>();
		List<EmployeeAttendance> findByEmpId = attendanceRepository.findByEmployeeId(empid);

		if (findByEmpId == null || findByEmpId.isEmpty()) {

			throw new UserNotFoundException("This user not found :" + empid);
		}
		for (EmployeeAttendance empAttendance : findByEmpId) {
			EmployeeAttendanceDTO dto = new EmployeeAttendanceDTO(empAttendance);

			dtoList.add(dto);
		}
		;
		return dtoList;

	}

	
	public List<AvgHoursAndOnTimeArrivalDto> AvgPerDayAndOntimeArrival(Long empid, LocalDate statDate,
			LocalDate endDate) throws UserNotFoundException {

		List<EmployeeAttendance> byEmployeeId = attendanceRepository.findByEmployeeId(empid);

		if (byEmployeeId == null || byEmployeeId.isEmpty()) {

			throw new UserNotFoundException("This user not found :" + empid);
		}
		List<AvgHoursAndOnTimeArrivalDto> aDto = new ArrayList<>();
		AvgHoursAndOnTimeArrivalDto avgDto = new AvgHoursAndOnTimeArrivalDto();
		List<EmployeeAttendance> employeeAttendances = attendanceRepository.findByEmployeeIdAndDateBetween(empid,
				statDate, endDate);
		log.info("range data :{}", employeeAttendances);
		int count = 0;
		int size = employeeAttendances.size();
		System.out.println(size);
		Duration totalEffectiveDuration = Duration.ZERO;

		for (EmployeeAttendance empAttendance : employeeAttendances) {

			String effectiveHoursStr = empAttendance.getEffectiveHours();

			LocalTime effectiveHours = LocalTime.parse(effectiveHoursStr, DateTimeFormatter.ofPattern("HH:mm:ss"));

			totalEffectiveDuration = totalEffectiveDuration.plusHours(effectiveHours.getHour())
					.plusMinutes(effectiveHours.getMinute());

			String status = empAttendance.getStatus();
			System.out.println(status);
			if (status.equals("OnTime")) {

				count++;
			}

		}

		long totalHours = totalEffectiveDuration.toHours();
		long totalMinutes = totalEffectiveDuration.toMinutes() % 60;
		String totalEffectiveHours = String.format("%02d:%02d", totalHours, totalMinutes);

		int workingDays = 5;
		String averageHoursPerDay = this.calculateAverageHoursPerDay(totalEffectiveHours, size);
		double onTimeArival = ((double) count / size) * 100;
		int p=(int) onTimeArival;
		String onTimeArrivalPer=String.valueOf(p)+" % ";
		avgDto.setAvgArivalPer(onTimeArrivalPer);
		avgDto.setAvgPerDay(averageHoursPerDay);
		aDto.add(avgDto);
		return aDto;

	}
	
	// Calculateing avg per week or month or custom range
	public  String calculateAverageHoursPerDay(String totalEffectiveHours, int workingDays) {
		String[] timeParts = totalEffectiveHours.split(":");
		int totalHours = Integer.parseInt(timeParts[0]);
		int totalMinutes = Integer.parseInt(timeParts[1]);
		int totalTimeInMinutes = totalHours * 60 + totalMinutes;
		int averageMinutesPerDay = totalTimeInMinutes / workingDays;
		int averageHours = averageMinutesPerDay / 60;
		int remainingMinutes = averageMinutesPerDay % 60;
		String format = String.format("%02dH:%02dM", averageHours, remainingMinutes);
		return format;
	}

}
